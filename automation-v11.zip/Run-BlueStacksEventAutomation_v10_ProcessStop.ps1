[CmdletBinding()]
param(
    [ValidatePattern('^[^:]+:\d+$')][string]$Serial = '127.0.0.1:5825',
    [ValidatePattern('^[A-Za-z0-9_.]+$')][string]$Package = 'com.hariwn.legendofcivilizations',
    [ValidateRange(1, 10000)][int]$Repeats = 80,
    [ValidateRange(0, 60000)][double]$EventDelayMilliseconds = 50,
    [ValidateRange(1, 300)][double]$EventTimeoutSeconds = 30,
    [ValidateRange(1, 10)][int]$MaxIterationAttempts = 3,
    [ValidateRange(5, 120)][int]$AdbCommandTimeoutSeconds = 15,
    [ValidateRange(0, 86400)][double]$InitialWaitSeconds = 300,
    [ValidateRange(0.1, 86400)][double]$RewardWaitSeconds = 22,
    [ValidateRange(0, 86400)][double]$CycleWaitSeconds = 300,
    [switch]$DisableLogs,
    [switch]$DisableScreenshots,
    [string]$ProgressFile = '',
    [string]$InstanceTag = '',
    [int]$LaunchX = 732,
    [int]$LaunchY = 276,
    [int]$RewardX = 463,
    [int]$RewardY = 1020
)

$ErrorActionPreference = 'Stop'
$adb = @('C:\Program Files\BlueStacks_nxt\HD-Adb.exe', 'C:\Program Files (x86)\BlueStacks_nxt\HD-Adb.exe') |
    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$eventWaiter = Join-Path $PSScriptRoot 'AdbEventWaiter.exe'
$eventText = '[main] Initial state received, starting session'
$logDirectory = Join-Path $PSScriptRoot 'timing-logs'
$screenshotDirectory = Join-Path $PSScriptRoot 'screenshots'

if ([string]::IsNullOrWhiteSpace($InstanceTag)) {
    $InstanceTag = ($Serial -replace '[^A-Za-z0-9_-]', '_') + '_' + $PID
}
$InstanceTag = $InstanceTag -replace '[^A-Za-z0-9_-]', '_'

if (-not $adb) { throw 'BlueStacks HD-Adb.exe was not found.' }
if (-not (Test-Path -LiteralPath $eventWaiter)) { throw "Event waiter was not found: $eventWaiter" }
New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
if (-not $DisableScreenshots) { New-Item -ItemType Directory -Path $screenshotDirectory -Force | Out-Null }
$runtimeLog = Join-Path $logDirectory "automation_runtime_${InstanceTag}_$(Get-Date -Format 'yyyyMMdd_HHmmss_fff').log"
$eventSignalFile = Join-Path $logDirectory "automation_event_${InstanceTag}.signal"
$script:CurrentStage = 'startup'
$healthFile = Join-Path $logDirectory "automation_health_${InstanceTag}.txt"
$watchdogLog = Join-Path $logDirectory "automation_watchdog_${InstanceTag}_$(Get-Date -Format 'yyyyMMdd_HHmmss_fff').log"
$watchdogScript = Join-Path $PSScriptRoot 'AutomationHangWatchdog.ps1'
$script:WatchdogProcess = $null

function Write-DiagnosticLog {
    param([string]$Level, [string]$Message)
    if ($DisableLogs) { return }
    try {
        $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') level=$Level pid=$PID stage=$script:CurrentStage $Message"
        [IO.File]::AppendAllText($runtimeLog, $line + [Environment]::NewLine, [Text.Encoding]::UTF8)
    } catch { }
}

function Set-Stage {
    param([string]$Name, [string]$Detail = '', [int]$AllowedSeconds = 90)
    $script:CurrentStage = $Name
    try {
        $deadline = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + ([long]$AllowedSeconds * 1000)
        [IO.File]::WriteAllText($healthFile, "$deadline|$Name", [Text.Encoding]::UTF8)
    } catch { }
    Write-DiagnosticLog 'INFO' $Detail
}

function Set-ProgressText {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($ProgressFile)) { return }
    try {
        $temporaryFile = "$ProgressFile.tmp"
        [IO.File]::WriteAllText($temporaryFile, $Text, [Text.Encoding]::UTF8)
        Move-Item -LiteralPath $temporaryFile -Destination $ProgressFile -Force
    }
    catch {
        Write-DiagnosticLog 'WARN' "progress_write_failed=$($_.Exception.Message -replace '[\r\n]+', ' ')"
    }
}

function Convert-ToCommandLineArgument {
    param([string]$Value)
    if ($Value -notmatch '[\s"]') { return $Value }
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

function Invoke-AdbProcess {
    param(
        [string[]]$Arguments,
        [bool]$UseSerial = $true,
        [int]$TimeoutSeconds = $AdbCommandTimeoutSeconds
    )
    $allArguments = @()
    if ($UseSerial) { $allArguments += @('-s', $Serial) }
    $allArguments += $Arguments
    $argumentText = ($allArguments | ForEach-Object { Convert-ToCommandLineArgument ([string]$_) }) -join ' '
    $info = New-Object Diagnostics.ProcessStartInfo
    $info.FileName = $adb
    $info.Arguments = $argumentText
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $info.RedirectStandardError = $true
    $process = [Diagnostics.Process]::Start($info)
    try {
        if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
            try { $process.Kill() } catch { }
            try { $process.WaitForExit(2000) | Out-Null } catch { }
            throw "ADB_TIMEOUT after ${TimeoutSeconds}s: $($Arguments -join ' ')"
        }
        $stdout = $process.StandardOutput.ReadToEnd()
        $stderr = $process.StandardError.ReadToEnd()
        return [pscustomobject]@{ ExitCode=$process.ExitCode; Output=$stdout; Error=$stderr }
    }
    finally { $process.Dispose() }
}

function Repair-AdbConnection {
    Write-DiagnosticLog 'WARN' "adb_repair_start serial=$Serial"
    try { Invoke-AdbProcess -Arguments @('disconnect', $Serial) -UseSerial $false -TimeoutSeconds 10 | Out-Null } catch { }
    Start-Sleep -Milliseconds 500
    $connect = Invoke-AdbProcess -Arguments @('connect', $Serial) -UseSerial $false -TimeoutSeconds 10
    Write-DiagnosticLog 'WARN' "adb_repair_connect exit=$($connect.ExitCode) output=$(($connect.Output + ' ' + $connect.Error).Trim())"
    Start-Sleep -Milliseconds 500
}

function Invoke-Adb {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Arguments)
    $commandText = $Arguments -join ' '
    for ($adbAttempt = 1; $adbAttempt -le 3; $adbAttempt++) {
        Write-DiagnosticLog 'ADB' "command_start=$commandText adbAttempt=$adbAttempt timeoutSeconds=$AdbCommandTimeoutSeconds"
        try {
            $result = Invoke-AdbProcess -Arguments $Arguments -UseSerial $true -TimeoutSeconds $AdbCommandTimeoutSeconds
            $combined = ($result.Output + ' ' + $result.Error).Trim()
            if ($result.ExitCode -eq 0) {
                Write-DiagnosticLog 'ADB' "command_ok=$commandText adbAttempt=$adbAttempt"
                if ($result.Output) { return ($result.Output -split "`r?`n" | Where-Object { $_ -ne '' }) }
                return
            }
            throw "ADB exit $($result.ExitCode): $combined"
        }
        catch {
            $message = $_.Exception.Message -replace '[\r\n]+',' '
            Write-DiagnosticLog 'ERROR' "adb_command_failed=$commandText adbAttempt=$adbAttempt error=$message"
            if ($adbAttempt -ge 3) { throw "ADB failed after 3 attempts: $commandText; $message" }
            Repair-AdbConnection
        }
    }
}

function Stop-Game {
    Set-Stage 'reward_home' 'Returning to Android home before reward force-stop'
    Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
    [Threading.Thread]::Sleep(3000)
    Set-Stage 'reward_force_stop' 'Force-stopping the game after reward action'
    Invoke-Adb shell am force-stop --user 0 $Package | Out-Null
}

function Save-RewardScreenshot {
    param([string]$RunStamp, [int]$CycleNumber, [int]$RewardRun)
    if ($DisableScreenshots) {
        Write-DiagnosticLog 'INFO' "reward_screenshot_skipped cycle=$CycleNumber rewardRun=$RewardRun"
        return
    }
    New-Item -ItemType Directory -Path $screenshotDirectory -Force | Out-Null
    $fileName = "reward_${InstanceTag}_${RunStamp}_cycle${CycleNumber}_run${RewardRun}_before.png"
    $localPath = Join-Path $screenshotDirectory $fileName
    $remotePath = "/data/local/tmp/$fileName"
    Set-Stage 'reward_screenshot_capture' "cycle=$CycleNumber rewardRun=$RewardRun path=$localPath"
    Invoke-Adb shell screencap '-p' $remotePath | Out-Null
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        Invoke-Adb pull $remotePath $localPath | Out-Null
    }
    finally {
        try { Invoke-Adb shell rm -f $remotePath | Out-Null } catch { }
        $ErrorActionPreference = $oldPreference
    }
    Write-Host "Reward screenshot saved: $localPath"
}

trap {
    $fatalMessage = $_.Exception.Message -replace '[\r\n]+', ' '
    if (Get-Command Write-DiagnosticLog -ErrorAction SilentlyContinue) {
        Write-DiagnosticLog 'FATAL' "unhandled_error=$fatalMessage"
    }
    if (Get-Command Set-ProgressText -ErrorAction SilentlyContinue) {
        Set-ProgressText "Automation stopped unexpectedly: $script:CurrentStage"
    }
    [Console]::Error.WriteLine("Automation fatal error: $fatalMessage")
    exit 1
}

if (-not (Test-Path -LiteralPath $watchdogScript)) { throw "Watchdog script was not found: $watchdogScript" }
$watchdogInfo = New-Object Diagnostics.ProcessStartInfo
$watchdogInfo.FileName = 'powershell.exe'
$watchdogInfo.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -WorkerPid {1} -HealthFile "{2}" -WatchdogLog "{3}"' -f $watchdogScript, $PID, $healthFile, $watchdogLog
$watchdogInfo.UseShellExecute = $false
$watchdogInfo.CreateNoWindow = $true
$script:WatchdogProcess = [Diagnostics.Process]::Start($watchdogInfo)

Set-Stage 'adb_connect' "process_started serial=$Serial package=$Package repeats=$Repeats eventDelayMs=$EventDelayMilliseconds"
Write-Host "Connecting to $Serial"
Repair-AdbConnection
Write-DiagnosticLog 'INFO' 'adb_connect_command_completed'
Set-Stage 'adb_device_check' 'Checking ADB device state'
if ((Invoke-Adb get-state | Select-Object -First 1) -ne 'device') { throw "ADB device is not connected: $Serial" }
Set-Stage 'package_check' 'Checking whether the game package is installed'
if (-not ((Invoke-Adb shell pm path $Package) -match '^package:')) { throw "Package is not installed: $Package" }

Set-Stage 'initial_cleanup' 'Returning home and force-stopping the game before the first cycle'
Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
[Threading.Thread]::Sleep(1000)
Invoke-Adb shell am force-stop --user 0 $Package | Out-Null

if ($InitialWaitSeconds -gt 0) {
    Set-Stage 'initial_wait' "seconds=$InitialWaitSeconds" ([int][Math]::Ceiling($InitialWaitSeconds) + 60)
    $initialDeadline = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + [long][Math]::Round($InitialWaitSeconds * 1000)
    Set-ProgressText "FirstCycleCountdown|$initialDeadline"
    Write-Host "Waiting $InitialWaitSeconds seconds before the first cycle"
    [Threading.Thread]::Sleep([int][Math]::Round($InitialWaitSeconds * 1000))
}

$cycleNumber = 1
while ($true) {
    $runStamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $csvPath = Join-Path $logDirectory "automation_${InstanceTag}_${runStamp}_cycle${cycleNumber}.csv"
    $failureLog = Join-Path $logDirectory "automation_errors_${InstanceTag}_${runStamp}_cycle${cycleNumber}.log"
    Write-Host "=== Cycle $cycleNumber started ==="
    Set-Stage 'cycle_start' "cycle=$cycleNumber repeats=$Repeats"

    for ($i = 1; $i -le $Repeats; $i++) {
        $iterationSucceeded = $false
        for ($attempt = 1; $attempt -le $MaxIterationAttempts; $attempt++) {
            Set-ProgressText "Current repetition: $i / $Repeats (cycle $cycleNumber, attempt $attempt/$MaxIterationAttempts)"
            $waiterProcess = $null
            $attemptError = $null
            try {
                Set-Stage 'iteration_prepare' "cycle=$cycleNumber iteration=$i attempt=$attempt"
                Remove-Item -LiteralPath $eventSignalFile -Force -ErrorAction SilentlyContinue
                Invoke-Adb logcat -c | Out-Null
                $waiterInfo = New-Object Diagnostics.ProcessStartInfo
                $waiterInfo.FileName = $eventWaiter
                $waiterInfo.Arguments = '"{0}" {1} "{2}" "{3}" {4}' -f $adb, $Serial, $eventText, $eventSignalFile, [int][Math]::Ceiling($EventTimeoutSeconds)
                $waiterInfo.UseShellExecute = $false
                $waiterInfo.CreateNoWindow = $true
                $waiterProcess = [Diagnostics.Process]::Start($waiterInfo)
                [Threading.Thread]::Sleep(200)
                Set-Stage 'iteration_home' "cycle=$cycleNumber iteration=$i attempt=$attempt"
                Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(1000)
                $tapTime = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                Set-Stage 'iteration_launch_tap' "cycle=$cycleNumber iteration=$i attempt=$attempt x=$LaunchX y=$LaunchY"
                Invoke-Adb shell input tap $LaunchX $LaunchY | Out-Null

                Set-Stage 'iteration_event_wait' "cycle=$cycleNumber iteration=$i attempt=$attempt timeoutSeconds=$EventTimeoutSeconds" ([int][Math]::Ceiling($EventTimeoutSeconds) + 30)
                $watch = [Diagnostics.Stopwatch]::StartNew()
                $detected = $false
                while ($watch.Elapsed.TotalSeconds -lt $EventTimeoutSeconds) {
                    if (Test-Path -LiteralPath $eventSignalFile) { $detected = $true; break }
                    if ($waiterProcess.HasExited) { throw "Event waiter exited early (exit $($waiterProcess.ExitCode))" }
                    [Threading.Thread]::Sleep(20)
                }
                if (-not $detected) { throw "Server session event was not detected within $EventTimeoutSeconds seconds" }
                $detectedTime = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                [Threading.Thread]::Sleep([int][Math]::Round($EventDelayMilliseconds))
                Set-Stage 'iteration_exit_home' "cycle=$cycleNumber iteration=$i attempt=$attempt detectedAfterMs=$($detectedTime - $tapTime)"
                Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(3000)
                Set-Stage 'iteration_force_stop' "cycle=$cycleNumber iteration=$i attempt=$attempt"
                Invoke-Adb shell am force-stop --user 0 $Package | Out-Null

                if (-not $DisableLogs) {
                    [pscustomobject]@{
                        Cycle = $cycleNumber; Iteration = $i; Attempt = $attempt
                        EventDelayMs = $EventDelayMilliseconds
                        TapToDetectionMs = $detectedTime - $tapTime; Completed = (Get-Date).ToString('o')
                    } | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Append
                }
                Write-Host "[$i/$Repeats] event detected; game stopped (attempt $attempt)"
                Set-Stage 'iteration_complete' "cycle=$cycleNumber iteration=$i attempt=$attempt"
                $iterationSucceeded = $true
            }
            catch {
                $attemptError = $_.Exception.Message
            }
            finally {
                if ($waiterProcess -and -not $waiterProcess.HasExited) {
                    $waiterProcess.Kill()
                    $waiterProcess.WaitForExit(2000) | Out-Null
                }
                if ($waiterProcess) { $waiterProcess.Dispose() }
                Remove-Item -LiteralPath $eventSignalFile -Force -ErrorAction SilentlyContinue
            }

            if ($iterationSucceeded) { break }
            $errorLine = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') cycle=$cycleNumber iteration=$i attempt=$attempt error=$attemptError"
            Write-DiagnosticLog 'ERROR' $errorLine
            if (-not $DisableLogs) { Add-Content -LiteralPath $failureLog -Value $errorLine -Encoding UTF8 }
            Write-Warning $errorLine
            if ($attempt -ge $MaxIterationAttempts) {
                if ($DisableLogs) { throw "Iteration $i failed after $MaxIterationAttempts attempts." }
                throw "Iteration $i failed after $MaxIterationAttempts attempts. See $failureLog"
            }

            Set-ProgressText "Retrying repetition: $i / $Repeats (cycle $cycleNumber, next attempt $($attempt + 1)/$MaxIterationAttempts)"
            try {
                Repair-AdbConnection
                Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(1000)
                Invoke-Adb shell am force-stop --user 0 $Package | Out-Null
                [Threading.Thread]::Sleep(1000)
            }
            catch { Write-DiagnosticLog 'WARN' "iteration_recovery_cleanup_failed=$($_.Exception.Message -replace '[\r\n]+',' ')" }
        }
    }

    for ($rewardRun = 1; $rewardRun -le 2; $rewardRun++) {
        Set-ProgressText "Collecting reward: $rewardRun / 2 (cycle $cycleNumber)"
        Write-Host "[Reward $rewardRun/2] Launching game"
        Set-Stage 'reward_launch_home' "cycle=$cycleNumber rewardRun=$rewardRun"
        Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
        [Threading.Thread]::Sleep(1000)
        Set-Stage 'reward_launch_tap' "cycle=$cycleNumber rewardRun=$rewardRun x=$LaunchX y=$LaunchY"
        Invoke-Adb shell input tap $LaunchX $LaunchY | Out-Null
        Set-Stage 'reward_loading_wait' "cycle=$cycleNumber rewardRun=$rewardRun seconds=$RewardWaitSeconds" ([int][Math]::Ceiling($RewardWaitSeconds) + 60)
        [Threading.Thread]::Sleep([int][Math]::Round($RewardWaitSeconds * 1000))
        Save-RewardScreenshot -RunStamp $runStamp -CycleNumber $cycleNumber -RewardRun $rewardRun
        Set-Stage 'reward_tap' "cycle=$cycleNumber rewardRun=$rewardRun x=$RewardX y=$RewardY"
        Invoke-Adb shell input tap $RewardX $RewardY | Out-Null
        [Threading.Thread]::Sleep(1000)
        Stop-Game
        Write-Host "[Reward $rewardRun/2] Game stopped"
    }

    Write-Host "Cycle $cycleNumber complete. Waiting $CycleWaitSeconds seconds"
    Set-Stage 'cycle_wait' "cycle=$cycleNumber seconds=$CycleWaitSeconds" ([int][Math]::Ceiling($CycleWaitSeconds) + 60)
    $nextCycleNumber = $cycleNumber + 1
    $cycleDeadline = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + [long][Math]::Round($CycleWaitSeconds * 1000)
    Set-ProgressText "NextCycleCountdown|$nextCycleNumber|$cycleDeadline"
    if ($CycleWaitSeconds -gt 0) { [Threading.Thread]::Sleep([int][Math]::Round($CycleWaitSeconds * 1000)) }
    $cycleNumber++
}

param(
    [Parameter(Mandatory)][int]$WorkerPid,
    [Parameter(Mandatory)][string]$HealthFile,
    [Parameter(Mandatory)][string]$WatchdogLog
)

$ErrorActionPreference = 'SilentlyContinue'

function Write-WatchdogLog {
    param([string]$Message)
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') workerPid=$WorkerPid $Message"
    [IO.File]::AppendAllText($WatchdogLog, $line + [Environment]::NewLine, [Text.Encoding]::UTF8)
}

Write-WatchdogLog 'watchdog_started'

while ($true) {
    Start-Sleep -Seconds 3
    $worker = Get-Process -Id $WorkerPid -ErrorAction SilentlyContinue
    if (-not $worker) {
        Write-WatchdogLog 'worker_exited_watchdog_stopping'
        exit 0
    }

    if (-not (Test-Path -LiteralPath $HealthFile)) { continue }
    try {
        $parts = ([IO.File]::ReadAllText($HealthFile)).Split('|')
        if ($parts.Count -lt 2) { continue }
        $deadline = [long]$parts[0]
        $stage = $parts[1]
        $now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
        if ($now -le $deadline) { continue }

        Write-WatchdogLog "hang_detected stage=$stage deadline=$deadline now=$now"
        & taskkill.exe /PID $WorkerPid /T /F | Out-Null
        Start-Sleep -Seconds 2
        if (Get-Process -Id $WorkerPid -ErrorAction SilentlyContinue) {
            try { (Get-Process -Id $WorkerPid).Kill() } catch { }
        }
        Write-WatchdogLog 'worker_termination_requested'
        exit 2
    }
    catch {
        Write-WatchdogLog "watchdog_read_error=$($_.Exception.Message -replace '[\r\n]+',' ')"
    }
}

[CmdletBinding()]
param(
    [ValidatePattern('^[^:]+:\d+$')][string]$Serial = '127.0.0.1:5825',
    [ValidatePattern('^[A-Za-z0-9_.]+$')][string]$Package = 'com.hariwn.legendofcivilizations',
    [ValidateRange(1, 10000)][int]$Repeats = 80,
    [ValidateRange(0, 60000)][double]$EventDelayMilliseconds = 50,
    [ValidateRange(1, 300)][double]$EventTimeoutSeconds = 30,
    [ValidateRange(1, 10)][int]$MaxIterationAttempts = 3,
    [ValidateRange(0, 86400)][double]$InitialWaitSeconds = 300,
    [ValidateRange(0.1, 86400)][double]$RewardWaitSeconds = 22,
    [ValidateRange(0, 86400)][double]$CycleWaitSeconds = 300,
    [string]$ProgressFile = '',
    [string]$InstanceTag = '',
    [int]$LaunchX = 732,
    [int]$LaunchY = 276,
    [int]$RewardX = 463,
    [int]$RewardY = 1020
)

$ErrorActionPreference = 'Stop'
$adb = @('C:\Program Files\BlueStacks_nxt\HD-Adb.exe', 'C:\Program Files (x86)\BlueStacks_nxt\HD-Adb.exe') |
    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$eventWaiter = Join-Path $PSScriptRoot 'AdbEventWaiter.exe'
$eventText = '[main] Initial state received, starting session'
$logDirectory = Join-Path $PSScriptRoot 'timing-logs'
$screenshotDirectory = Join-Path $PSScriptRoot 'screenshots'

if ([string]::IsNullOrWhiteSpace($InstanceTag)) {
    $InstanceTag = ($Serial -replace '[^A-Za-z0-9_-]', '_') + '_' + $PID
}
$InstanceTag = $InstanceTag -replace '[^A-Za-z0-9_-]', '_'

if (-not $adb) { throw 'BlueStacks HD-Adb.exe was not found.' }
if (-not (Test-Path -LiteralPath $eventWaiter)) { throw "Event waiter was not found: $eventWaiter" }
New-Item -ItemType Directory -Path $logDirectory, $screenshotDirectory -Force | Out-Null

function Set-ProgressText {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($ProgressFile)) { return }
    $temporaryFile = "$ProgressFile.tmp"
    [IO.File]::WriteAllText($temporaryFile, $Text, [Text.Encoding]::UTF8)
    Move-Item -LiteralPath $temporaryFile -Destination $ProgressFile -Force
}

function Invoke-Adb {
    param([Parameter(ValueFromRemainingArguments)][string[]]$Arguments)
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $output = & $adb -s $Serial @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $oldPreference }
    if ($exitCode -ne 0) { throw "ADB failed: $($Arguments -join ' ')`n$($output -join "`n")" }
    return $output
}

function Stop-Game {
    Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
    [Threading.Thread]::Sleep(3000)
    Invoke-Adb shell am force-stop --user 0 $Package | Out-Null
}

function Save-RewardScreenshot {
    param([string]$RunStamp, [int]$CycleNumber, [int]$RewardRun)
    $fileName = "reward_${InstanceTag}_${RunStamp}_cycle${CycleNumber}_run${RewardRun}_before.png"
    $localPath = Join-Path $screenshotDirectory $fileName
    $remotePath = "/data/local/tmp/$fileName"
    Invoke-Adb shell screencap '-p' $remotePath | Out-Null
    $oldPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $adb -s $Serial pull $remotePath $localPath | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "Screenshot pull failed: $localPath" }
    }
    finally {
        & $adb -s $Serial shell rm -f $remotePath | Out-Null
        $ErrorActionPreference = $oldPreference
    }
    Write-Host "Reward screenshot saved: $localPath"
}

Write-Host "Connecting to $Serial"
& $adb connect $Serial | Out-Host
if ((& $adb -s $Serial get-state 2>$null | Select-Object -First 1) -ne 'device') { throw "ADB device is not connected: $Serial" }
if (-not ((Invoke-Adb shell pm path $Package) -match '^package:')) { throw "Package is not installed: $Package" }

Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
[Threading.Thread]::Sleep(1000)
Invoke-Adb shell am force-stop --user 0 $Package | Out-Null

if ($InitialWaitSeconds -gt 0) {
    Set-ProgressText "Waiting before first cycle: $InitialWaitSeconds sec"
    Write-Host "Waiting $InitialWaitSeconds seconds before the first cycle"
    [Threading.Thread]::Sleep([int][Math]::Round($InitialWaitSeconds * 1000))
}

$cycleNumber = 1
while ($true) {
    $runStamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $csvPath = Join-Path $logDirectory "automation_${InstanceTag}_${runStamp}_cycle${cycleNumber}.csv"
    $failureLog = Join-Path $logDirectory "automation_errors_${InstanceTag}_${runStamp}_cycle${cycleNumber}.log"
    Write-Host "=== Cycle $cycleNumber started ==="

    for ($i = 1; $i -le $Repeats; $i++) {
        $iterationSucceeded = $false
        for ($attempt = 1; $attempt -le $MaxIterationAttempts; $attempt++) {
            Set-ProgressText "Current repetition: $i / $Repeats (cycle $cycleNumber, attempt $attempt/$MaxIterationAttempts)"
            $cycleLog = Join-Path $logDirectory "automation_event_${InstanceTag}_${runStamp}_${cycleNumber}_$('{0:D3}' -f $i)_attempt${attempt}.txt"
            $waiterProcess = $null
            $attemptError = $null
            try {
                Invoke-Adb logcat -c | Out-Null
                $waiterInfo = New-Object Diagnostics.ProcessStartInfo
                $waiterInfo.FileName = $eventWaiter
                $waiterInfo.Arguments = '"{0}" {1} "{2}" "{3}" {4}' -f $adb, $Serial, $eventText, $cycleLog, [int][Math]::Ceiling($EventTimeoutSeconds)
                $waiterInfo.UseShellExecute = $false
                $waiterInfo.CreateNoWindow = $true
                $waiterProcess = [Diagnostics.Process]::Start($waiterInfo)
                [Threading.Thread]::Sleep(200)
                Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(1000)
                $tapTime = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                Invoke-Adb shell input tap $LaunchX $LaunchY | Out-Null

                $watch = [Diagnostics.Stopwatch]::StartNew()
                $detected = $false
                while ($watch.Elapsed.TotalSeconds -lt $EventTimeoutSeconds) {
                    if (Test-Path -LiteralPath $cycleLog) { $detected = $true; break }
                    if ($waiterProcess.HasExited) { throw "Event waiter exited early (exit $($waiterProcess.ExitCode))" }
                    [Threading.Thread]::Sleep(20)
                }
                if (-not $detected) { throw "Server session event was not detected within $EventTimeoutSeconds seconds" }
                $detectedTime = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
                [Threading.Thread]::Sleep([int][Math]::Round($EventDelayMilliseconds))
                Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(3000)
                Invoke-Adb shell am force-stop --user 0 $Package | Out-Null

                [pscustomobject]@{
                    Cycle = $cycleNumber; Iteration = $i; Attempt = $attempt
                    EventDelayMs = $EventDelayMilliseconds
                    TapToDetectionMs = $detectedTime - $tapTime; Completed = (Get-Date).ToString('o')
                } | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Append
                Write-Host "[$i/$Repeats] event detected; game stopped (attempt $attempt)"
                $iterationSucceeded = $true
            }
            catch {
                $attemptError = $_.Exception.Message
            }
            finally {
                if ($waiterProcess -and -not $waiterProcess.HasExited) {
                    $waiterProcess.Kill()
                    $waiterProcess.WaitForExit(2000) | Out-Null
                }
                if ($waiterProcess) { $waiterProcess.Dispose() }
            }

            if ($iterationSucceeded) { break }
            $errorLine = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff') cycle=$cycleNumber iteration=$i attempt=$attempt error=$attemptError"
            Add-Content -LiteralPath $failureLog -Value $errorLine -Encoding UTF8
            Write-Warning $errorLine
            if ($attempt -ge $MaxIterationAttempts) {
                throw "Iteration $i failed after $MaxIterationAttempts attempts. See $failureLog"
            }

            Set-ProgressText "Retrying repetition: $i / $Repeats (cycle $cycleNumber, next attempt $($attempt + 1)/$MaxIterationAttempts)"
            $oldPreference = $ErrorActionPreference
            try {
                $ErrorActionPreference = 'Continue'
                & $adb connect $Serial | Out-Null
                & $adb -s $Serial shell input keyevent KEYCODE_HOME | Out-Null
                [Threading.Thread]::Sleep(1000)
                & $adb -s $Serial shell am force-stop --user 0 $Package | Out-Null
                [Threading.Thread]::Sleep(1000)
            }
            finally { $ErrorActionPreference = $oldPreference }
        }
    }

    for ($rewardRun = 1; $rewardRun -le 2; $rewardRun++) {
        Set-ProgressText "Collecting reward: $rewardRun / 2 (cycle $cycleNumber)"
        Write-Host "[Reward $rewardRun/2] Launching game"
        Invoke-Adb shell input keyevent KEYCODE_HOME | Out-Null
        [Threading.Thread]::Sleep(1000)
        Invoke-Adb shell input tap $LaunchX $LaunchY | Out-Null
        [Threading.Thread]::Sleep([int][Math]::Round($RewardWaitSeconds * 1000))
        Save-RewardScreenshot -RunStamp $runStamp -CycleNumber $cycleNumber -RewardRun $rewardRun
        Invoke-Adb shell input tap $RewardX $RewardY | Out-Null
        [Threading.Thread]::Sleep(1000)
        Stop-Game
        Write-Host "[Reward $rewardRun/2] Game stopped"
    }

    Write-Host "Cycle $cycleNumber complete. Waiting $CycleWaitSeconds seconds"
    Set-ProgressText "Waiting for next cycle: $CycleWaitSeconds sec"
    if ($CycleWaitSeconds -gt 0) { [Threading.Thread]::Sleep([int][Math]::Round($CycleWaitSeconds * 1000)) }
    $cycleNumber++
}
